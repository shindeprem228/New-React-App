import React from "react";

function Footer()
{
    return (<footer style={{padding: "10px"}}>
        <h5 style={{textAlign: "center" ,color: "grey"}}>Designed By Prem Shinde</h5>
    </footer>);
}

export default Footer;